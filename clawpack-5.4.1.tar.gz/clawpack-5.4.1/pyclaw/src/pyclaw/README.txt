
begin_html

<h2>Python scripts and modules for Clawpack</h2>

<b>Directory claw/python/pyclaw</b>

These need to be cleaned up, reorganized, and better documented...


<ul>

<li> [code: data.py]

<li> [code: solution.py]

</ul>

end_html
