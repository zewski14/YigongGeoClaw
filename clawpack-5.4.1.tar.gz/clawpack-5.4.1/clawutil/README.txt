This repository will host Clawpack utility routines.
