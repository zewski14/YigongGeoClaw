
.. _geoplot:

========================================================
GeoClaw plotting tools
========================================================

The module `$CLAW/pyclaw/plotters/geoplot.py` contains some useful tools for
plotting GeoClaw output.

To be continued.  See comments in the module.

For information on using masked arrays, see:
 
 * `Masked array operations <http://docs.scipy.org/doc/numpy/reference/routines.ma.html>`_

