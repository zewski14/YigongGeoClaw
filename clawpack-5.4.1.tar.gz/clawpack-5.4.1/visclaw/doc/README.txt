This directory is for documentation.

To make the documentation in this directory, run
  make htmls
in the doc directory of the doc repository, after insuring that
  visclaw_doc
is a link to this directory.
