inp = input('Hit <return> for next plot, k for keyboard  ','s');
if strcmp(inp,'k')
  keyboard
  end
