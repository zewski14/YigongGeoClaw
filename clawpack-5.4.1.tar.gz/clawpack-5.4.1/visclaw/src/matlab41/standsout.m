%
% Use this colormap to get things to stand out, using either black or white
%

colormap('default');
c = colormap;

cnew = [0.85  0.85 1; c; 1    0.85 0.85];
colormap(cnew);
