% use this map for contour plots. All q values will get
% mapped to white.

colormap([1 1 1]);
