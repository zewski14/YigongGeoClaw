map1 = 1:-.1:0;
redwhitemap=[1+0*map1',map1',map1'];
colormap(redwhitemap)

