function set_mpirank(mpirank)

% Internal routine for Clawpack graphics.

global mpi_set_mpirank;

mpi_set_mpirank = mpirank;
