% use to edit afterframe.m from matlab and then clear this file so
% changes take effect

!vi afterframe.m
clear afterframe

