function set_blocknumber(bn)

% Internal routine for Clawpack graphics.

global bn_set_blocknumber;

bn_set_blocknumber = bn;
