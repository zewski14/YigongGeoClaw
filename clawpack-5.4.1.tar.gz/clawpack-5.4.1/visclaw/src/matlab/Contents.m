%
% For help on Clawpack graphics routines, type 'help clawgraphics'.
%
