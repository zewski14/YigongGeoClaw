num_waves = 3
num_eqn   = 3

# Conserved quantities
pressure = 0
x_velocity = 1
y_velocity = 2

