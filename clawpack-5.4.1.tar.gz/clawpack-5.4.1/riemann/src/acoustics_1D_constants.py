num_waves = 2
num_eqn   = 2

# Conserved quantities
pressure = 0
velocity = 1

