num_waves = 2
num_eqn   = 2
num_aux   = 2

# Conserved quantities
pressure = 0
velocity = 1

# Auxiliary variables
impedance = 0
sound_speed = 1
