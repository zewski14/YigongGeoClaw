num_waves = 1
num_eqn   = 1

# Conserved quantities
q = 0

# Auxiliary variables
velocity = 0
